#!/bin/sh
#
# Als Vorbereitung muss der IO-Name des Cul im Rasperry PI OS bekannt sein. Weiter muss der Code der Funksteckdose bekannt sein. Beide Werte müssen als Parameter $#
# sudo sh install_cul.sh TTY000 FF000000


if [ $# -ne 2 ];then
   echo "Incorrect amount of Arguments, exiting."
   exit
fi

wget http://culfw.de/culfw-1.67.tar.gz
tar xfv culfw-1.67.tar.gz
apt install -y make gcc-avr avrdude avr-libc
cd culfw-1.67/Devices/nanoCUL/
make
make program


perl /opt/fhem/fhem.pl 7072 "define nanoCUL CUL /dev/$1@38400 1234"
perl /opt/fhem/fhem.pl 7072 'attr nanoCUL rfmode HomeMatic'
perl /opt/fhem/fhem.pl 7072 'attr nanoCUL room 241_Weihnachtsbeleuchtung'

X="0F FF F0"

perl /opt/fhem/fhem.pl 7072 "define funkLamp IT $2$X"
perl /opt/fhem/fhem.pl 7072 'attr funkLamp IODev nanoCUL'
perl /opt/fhem/fhem.pl 7072 'attr funkLamp model itswitch'
perl /opt/fhem/fhem.pl 7072 'attr funkLamp room 241_Weihnachtsbeleuchtung'
perl /opt/fhem/fhem.pl 7072 'save'




