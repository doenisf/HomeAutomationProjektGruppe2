#!/bin/sh
#Erwartete Eingabe: IP FritzBox und MAC-Adresse iPhone.
# sudo sh install_anwesenheitserkennung.sh 192.168.XXX.XXX XX:YY:AA:SS:DD:FF

if [ $# -ne 2 ];then
   echo "Incorrect amount of Arguments, exiting."
   exit
fi

unset username
unset password
echo -n "username:\n"
read user
echo -n "password:\n"
stty -echo
read  pass
stty echo


perl /opt/fhem/fhem.pl 7072 "define FritzBox FRITZBOX $1"
perl /opt/fhem/fhem.pl 7072 "attr FritzBox boxUser $user"
perl /opt/fhem/fhem.pl 7072 "set FritzBox password $pass"
perl /opt/fhem/fhem.pl 7072 'attr FritzBox allowTR064Command 1'
perl /opt/fhem/fhem.pl 7072 'attr FritzBox room 99_Fritz'
perl /opt/fhem/fhem.pl 7072 "define iPhone PRESENCE function {checkAllFritzMACpresent(\"$2\") } 01 01"
perl /opt/fhem/fhem.pl 7072 'attr iPhone room 98_Phones'
perl /opt/fhem/fhem.pl 7072 'define a_funkLamp_anwesenheitsCheck at +*00:00:01 {modusAnwesenheit("funkLamp", 17, 7)}'
perl /opt/fhem/fhem.pl 7072 'attr a_funkLamp_anwesenheitsCheck room 241_Weihnachtsbeleuchtung'
perl /opt/fhem/fhem.pl 7072 'save'
