#!/bin/sh
#make dir and cd
dir=`pwd`
mkdir /root/ca
cd /root/ca

#make pem
echo "fhem.SSL"
openssl req -new -x509 -newkey rsa:2048 -keyout fhemSSL.pem -out cacert.pem -days 3650
chmod 600 fhemSSL.pem

#generate rsa
echo "serverkey.pem"
openssl genrsa -out serverkey.pem -aes128 2048


openssl rsa -in serverkey.pem -out serverkey.pem

echo "Enter IP of PI in Common Name!!!!"
openssl req -new -key serverkey.pem -out req.pem -nodes

# Changes to openssl.cnf
rm -f /etc/ssl/openssl.cnf
cp $dir/files/openssl.cnf.prefilled /etc/ssl/openssl.cnf
chown root:root /etc/ssl/openssl.cnf


# new files 
echo 01 > serial
touch index.txt


# ca 
echo "ca req.pem"
openssl ca -in req.pem -notext -out servercert.pem

#new dir in /opt/fhem
mkdir /opt/fhem/certs

cp serverkey.pem /opt/fhem/certs/serverkey.pm
cp servercert.pem /opt/fhem/certs/servercert.pm

chown -R fhem:dialout /opt/fhem/certs/


perl /opt/fhem/fhem.pl 7072 'attr WEB sslVersion TLSv12:!SSLv3'
perl /opt/fhem/fhem.pl 7072 'attr WEB HTTPS 1'
perl /opt/fhem/fhem.pl 7072 'save'

