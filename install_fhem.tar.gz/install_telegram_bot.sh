#!/bin/sh
#Expected Arguments: Botname API-key Raum Benutzername
#Example call: sudo sh install_telegram_bot.sh SensorDatenFhem_bot 5086529595:AAGoVMH8AIwA_RCBONvtUI6hft_lYySYmRY 242_Sturmwetterwarnung Mightyrey

if [ $# -ne 4 ];then
   echo "Incorrect amount of Arguments, exiting."
   exit
fi

botName=$1
APIkey=$2
roomName=$3
name=$4



perl /opt/fhem/fhem.pl 7072 "define $botName TelegramBot $APIkey"
perl /opt/fhem/fhem.pl 7072 "attr $botName room $roomName"
perl /opt/fhem/fhem.pl 7072 "attr $botName pollingTimeout 120 "
perl /opt/fhem/fhem.pl 7072 "attr $botName defaultPeer @$name"
perl /opt/fhem/fhem.pl 7072 'save'