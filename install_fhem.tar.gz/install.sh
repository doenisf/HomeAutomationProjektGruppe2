#!/bin/sh
#
#Installing FHEM as by the Step-by-Step Guide.
#Gruppe 2 - WWI2019D - DHBW Stuttgart
#
# Skript erwartet ein Argument, die IP des Shellys. Dieser muss zuvor mit dem WLAN verbunden sein. Seine IP kann am Router in Erfahrung gebracht werden. 
#
# Aufruf dieses Skriptes: sudo sh install.sh 192.168.XXX.XXX
#
#Nach der automatischen Installation müssen manuell folgende Skripte mit ihren Paramteren angestartet werden: 
#
#   - install_SSL.sh
#   - install_anwesenheitserkennung.sh
#   - install_telegram_bot.sh
#   - install_cul.sh
#
# Der Shelly muss schon mit dem WLAN verbunden sein, wie in Punkt "Funktion Photovoltaik/Balkonkraftwerk" beschrieben. 

if [ $# -ne 1 ];then
   echo "Incorrect amount of Arguments, exiting."
   exit
fi

# Dependencies 
apt update -y
apt upgrade -y 
apt install -y wget 
apt install -y libfuse2
apt install -y libffi-dev 
apt install -y make 
apt install -y gcc-avr 
apt install -y avrdude 
apt install -y avr-libc 
apt install -y sqlite3 libdbi-perl libdbd-sqlite3-perl 


#Perl Dependencies

apt -y install perl-base libdevice-serialport-perl libwww-perl libio-socket-ssl-perl libcgi-pm-perl libjson-perl sqlite3 libdbd-sqlite3-perl libtext-diff-perl libtimedate-perl libmail-imapclient-perl libgd-graph-perl libtext-csv-perl libxml-simple-perl liblist-moreutils-perl fonts-liberation libimage-librsvg-perl libgd-text-perl libsocket6-perl libio-socket-inet6-perl libmime-base64-perl libimage-info-perl libusb-1.0-0-dev libnet-server-perl
apt -y install libdate-manip-perl libhtml-treebuilder-xpath-perl libmojolicious-perl libxml-bare-perl libauthen-oath-perl libconvert-base32-perl libmodule-pluggable-perl libnet-bonjour-perl libcrypt-urandom-perl nodejs npm libnet-dbus-perl
apt -y install libio-socket-ssl-perl
apt -y install libwww-perl
apt -y install libsoap-lite-perl libnet-telnet-perl
apt -y install libdatetime-format-strptime-perl libtime-piece-perl

#Installing FHEM

wget http://fhem.de/fhem-6.1.deb
dpkg -i fhem-6.1.deb
useradd --system --home /opt/fhem --gid dialout --shell /bin/false fhem
cp /opt/fhem/contrib/init-scripts/fhem.service /etc/systemd/system/
systemctl daemon-reload



#evil magic
systemctl stop fhem

echo "define tPort telnet 7072 global" >> /opt/fhem/fhem.cfg
echo "setuuid tPort 61df18fe-f33f-7a16-f5f4-dcf9c8671780f74c" >> /opt/fhem/fhem.cfg
echo "define allowed_tPort allowed" >> /opt/fhem/fhem.cfg
echo "setuuid allowed_tPort 61df1914-f33f-7a16-56cd-03382e3488cf2648" >> /opt/fhem/fhem.cfg

echo "attr allowed_tPort globalpassword start123" >> /opt/fhem/fhem.cfg
echo "attr allowed_tPort validFor tPort" >> /opt/fhem/fhem.cfg

systemctl start fhem

#end of evil magic

# FTUI Setup 
sleep 5s
perl /opt/fhem/fhem.pl 7072 'update all https://raw.githubusercontent.com/uniqueck/fhem-abfall/master/controls_fhemabfall.txt'
perl /opt/fhem/fhem.pl 7072 'update all https://raw.githubusercontent.com/knowthelist/fhem-tablet-ui/master/controls_fhemtabletui.txt'
perl /opt/fhem/fhem.pl 7072 'define TABLETUI HTTPSRV ftui/ ./www/tablet/ Tablet-UI' 
perl /opt/fhem/fhem.pl 7072 'attr WEB JavaScripts codemirror/fhem_codemirror.js'
perl /opt/fhem/fhem.pl 7072 'attr WEB longpoll websocket'

perl /opt/fhem/fhem.pl 7072 'save'
perl /opt/fhem/fhem.pl 7072 'shutdown restart'

# Install FTUI Files 
systemctl stop fhem 

rm -rf /opt/fhem/www/tablet
cd /opt/fhem/www
git clone https://github.com/tabascoel/tablet.git
cd -


# Install 99_MyUtils files 
cp -r `pwd`/files/99_* /opt/fhem/FHEM/
chown pi:dialout /opt/fhem/FHEM/99_*

# install_balkonkraftwerk
systemctl start fhem 
sleep 5s

# Absicht, bitte stehen lassen 
perl /opt/fhem/fhem.pl 7072 "define infrarotheizung Shelly $1"
perl /opt/fhem/fhem.pl 7072 'attr infrarotheizung model shelly2.5'
perl /opt/fhem/fhem.pl 7072 'attr infrarotheizung mode relay'
perl /opt/fhem/fhem.pl 7072 'attr infrarotheizung defchannel 1'
perl /opt/fhem/fhem.pl 7072 'attr infrarotheizung room 243_Balkonkraftwerk'


perl /opt/fhem/fhem.pl 7072 "define infrarotheizung Shelly $1"
perl /opt/fhem/fhem.pl 7072 'attr infrarotheizung model shelly2.5'
perl /opt/fhem/fhem.pl 7072 'attr infrarotheizung mode relay'
perl /opt/fhem/fhem.pl 7072 'attr infrarotheizung defchannel 1'
perl /opt/fhem/fhem.pl 7072 'attr infrarotheizung room 243_Balkonkraftwerk'


perl /opt/fhem/fhem.pl 7072 "define balkonkraftwerk Shelly $1"
perl /opt/fhem/fhem.pl 7072 'attr balkonkraftwerk model shelly2.5'
perl /opt/fhem/fhem.pl 7072 'attr balkonkraftwerk mode relay'
perl /opt/fhem/fhem.pl 7072 'attr balkonkraftwerk defchannel 0'
perl /opt/fhem/fhem.pl 7072 'attr balkonkraftwerk room 243_Balkonkraftwerk'


perl /opt/fhem/fhem.pl 7072 "define wasserBoiler Shelly $1"
perl /opt/fhem/fhem.pl 7072 'attr wasserBoiler model shelly2.5'
perl /opt/fhem/fhem.pl 7072 'attr wasserBoiler mode relay'
perl /opt/fhem/fhem.pl 7072 'attr wasserBoiler defchannel 1'
perl /opt/fhem/fhem.pl 7072 'attr wasserBoiler room 243_Wasserboiler'



perl /opt/fhem/fhem.pl 7072 'save'

# install_db.sh

sqlite3 /opt/fhem/fhem.db "CREATE TABLE history (TIMESTAMP TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, DEVICE varchar(64), TYPE varchar(64), EVENT varchar(512), READING varchar(64), VALUE varchar(128), UNIT varchar(32));"
sqlite3 /opt/fhem/fhem.db "CREATE TABLE current (TIMESTAMP TIMESTAMP, DEVICE varchar(64), TYPE varchar(64), EVENT varchar(512), READING varchar(64), VALUE varchar(128), UNIT varchar(32));"
sqlite3 /opt/fhem/fhem.db 'CREATE INDEX Search_Idx ON `history` (DEVICE, READING, TIMESTAMP);'

chown fhem /opt/fhem/fhem.db
chmod 600 /opt/fhem/fhem.db
touch /opt/fhem/db.conf
echo '%dbconfig= (
  connection => "SQLite:dbname=/opt/fhem/fhem.db",
  user => "",
  password => ""
);' >> /opt/fhem/db.conf 

systemctl restart fhem

sleep 5s

perl /opt/fhem/fhem.pl 7072 'setreading balkonkraftwerk sendData [balkonkraftwerk:power_0]'
perl /opt/fhem/fhem.pl 7072 'define logdb DbLog /opt/fhem/db.conf balkonkraftwerk:sendData.*'
perl /opt/fhem/fhem.pl 7072 'define timerSetReading at +*00:01:00 setreading balkonkraftwerk sendData [balkonkraftwerk:power_0]'
perl /opt/fhem/fhem.pl 7072 'save'


perl /opt/fhem/fhem.pl 7072 'define repBalkonkraftwerkDaily DbRep logdb'
perl /opt/fhem/fhem.pl 7072 'attr repBalkonkraftwerkDaily reading sendData'
perl /opt/fhem/fhem.pl 7072 'attr repBalkonkraftwerkDaily aggregation day'
perl /opt/fhem/fhem.pl 7072 'attr repBalkonkraftwerkDaily device balkonkraftwerk'
perl /opt/fhem/fhem.pl 7072 'attr repBalkonkraftwerkDaily timeDiffToNow d:1 FullDay'
perl /opt/fhem/fhem.pl 7072 'define repDaily at *23:59:59 set repBalkonkraftwerkDaily sumValue writeToDBSingle'

perl /opt/fhem/fhem.pl 7072 'define repBalkonkraftwerkMonthly DbRep logdb'
perl /opt/fhem/fhem.pl 7072 'attr repBalkonkraftwerkMonthly reading sendData'
perl /opt/fhem/fhem.pl 7072 'attr repBalkonkraftwerkMonthly aggregation month'
perl /opt/fhem/fhem.pl 7072 'attr repBalkonkraftwerkMonthly device balkonkraftwerk'
perl /opt/fhem/fhem.pl 7072 'attr repBalkonkraftwerkMonthly timeDiffToNow d:31 FullDay'
perl /opt/fhem/fhem.pl 7072 'define repMonthly at *23:59:59 {if ((strftime "%d",localtime time+86400) eq "01") {set repBalkonkraftwerkMonthly sumValue writeToDBSingle}}'

perl /opt/fhem/fhem.pl 7072 'save'


# install_weihnachtsbeleuchtung

perl /opt/fhem/fhem.pl 7072 'define a_funkLamp_morning_off at *07:00:00 set funkLamp off'

perl /opt/fhem/fhem.pl 7072 'attr a_funkLamp_morning_off room 241_Weihnachtsbeleuchtung'
perl /opt/fhem/fhem.pl 7072 'define a_funkLamp_evening_on at *17:00:00 set funkLamp on'
perl /opt/fhem/fhem.pl 7072 'attr a_funkLamp_evening_on room 241_Weihnachtsbeleuchtung'

perl /opt/fhem/fhem.pl 7072 'attr global latitude 48.773486'
perl /opt/fhem/fhem.pl 7072 'attr global longitude 9.170658'

perl /opt/fhem/fhem.pl 7072 'define doif_funk_sonne doif ([{sunset("REAL")}]) (set funkLamp on) DOELSEIF ([{sunrise("REAL")}]) (set funkLamp off)'
perl /opt/fhem/fhem.pl 7072 'attr doif_funk_sonne room 241_Weihnachtsbeleuchtung '


perl /opt/fhem/fhem.pl 7072 'define doif_funk_szeit DOIF ([{sunset("REAL")}]) (set funkLamp on) DOELSEIF ([{sunrise_abs("REAL",0,"00:00","07:30")}]) (set funkLamp off)'
perl /opt/fhem/fhem.pl 7072 'attr doif_funk_szeit room 241_Weihnachtsbeleuchtung'

perl /opt/fhem/fhem.pl 7072 'attr doif_funk_sonne disable 1'
perl /opt/fhem/fhem.pl 7072 'attr doif_funk_szeit disable 1'

perl /opt/fhem/fhem.pl 7072 'save'


# install_betriebmoduswahl  Weihnachtsbeleuchtung

perl /opt/fhem/fhem.pl 7072 'define funkLampModus dummy'
perl /opt/fhem/fhem.pl 7072 'attr funkLampModus room 241_Weihnachtsbeleuchtung'
perl /opt/fhem/fhem.pl 7072 'attr funkLampModus setList switch:festeZeit,Sonne,SZeit,Anwesenheit,Manuell'

perl /opt/fhem/fhem.pl 7072 'define doif_funk_general DOIF ([funkLampModus:"festeZeit"])(attr doif_funk_sonne disable 1)(attr doif_funk_szeit disable 1)(attr a_funkLamp_anwesenheitsCheck disable 1)(attr a_funkLamp_evening_on disable 0)(attr a_funkLamp_morning_off disable 0)({checkTime("funkLamp", 17, 7)})DOELSEIF ([funkLampModus:"Sonne"])(attr doif_funk_sonne disable 0)(attr doif_funk_szeit disable 1)(attr a_funkLamp_anwesenheitsCheck disable 1)(attr a_funkLamp_evening_on disable 1)(attr a_funkLamp_morning_off disable 1)({checkTime("funkLamp", sunset_abs(), sunrise_abs())})DOELSEIF ([funkLampModus:"SZeit"])(attr doif_funk_sonne disable 1)(attr doif_funk_szeit disable 0)(attr a_funkLamp_anwesenheitsCheck disable 1)(attr a_funkLamp_evening_on disable 1)(attr a_funkLamp_morning_off disable 1)({checkTime("funkLamp", sunset_abs(), sunrise_abs("REAL",0,"00:00","07:30"))})DOELSEIF ([funkLampModus:"Anwesenheit"])(attr doif_funk_sonne disable 1)(attr doif_funk_szeit disable 1)(attr a_funkLamp_anwesenheitsCheck disable 0)(attr a_funkLamp_evening_on disable 1)(attr a_funkLamp_morning_off disable 1)DOELSEIF([funkLampModus:"Manuell"])(attr doif_funk_sonne disable 1)(attr doif_funk_szeit disable 1)(attr a_funkLamp_anwesenheitsCheck disable 1)(attr a_funkLamp_evening_on disable 1)(attr a_funkLamp_morning_off disable 1)'


perl /opt/fhem/fhem.pl 7072 'attr doif_funk_general room 241_Weihnachtsbeleuchtung'
perl /opt/fhem/fhem.pl 7072 'save'

# install_sensordaten_hochdorf

perl /opt/fhem/fhem.pl 7072 'define SensorDaten HTTPMOD https://measurements.mobile-alerts.eu/Home/SensorsOverview?phoneid=285142992122  60'
perl /opt/fhem/fhem.pl 7072 'attr SensorDaten reading01Regex requestHeader1'
perl /opt/fhem/fhem.pl 7072 'attr SensorDaten requestHeader1 User-Agent: Mozilla/5.0 (Windows NT 6.0)'
perl /opt/fhem/fhem.pl 7072 'attr SensorDaten reading02Name Windgeschwindigkeit'
perl /opt/fhem/fhem.pl 7072 'attr SensorDaten reading02Regex Windgeschwindigkeit[\S\s\r\n]*?>([\-\d\d\,\d]+)'
perl /opt/fhem/fhem.pl 7072 'attr SensorDaten reading02Expr join ".", (split /,/, $val)'
perl /opt/fhem/fhem.pl 7072 'attr SensorDaten reading03Name Böe'
perl /opt/fhem/fhem.pl 7072 'attr SensorDaten reading03Regex B&#246[\S\s\r\n]*?>([\-\d\d\,\d]+)'
perl /opt/fhem/fhem.pl 7072 'attr SensorDaten reading03Expr join ".", (split /,/, $val) '
perl /opt/fhem/fhem.pl 7072 'attr SensorDaten reading04Name Windrichtung'
perl /opt/fhem/fhem.pl 7072 'attr SensorDaten reading04Regex Windrichtung[\S\s\r\n]*?>(?|(Norde)|(Nordnordost)|(Nordost)|(Ostnordost)|(Ost)|(Ostsüdost)|(Südost)|(Südsüdost)|(Süd)|(Südsüdwest)|(Südwest)|(Westsüdwest)|(West)|(Westnordwest)|(Nordwest)|(Nordnordwest))'
perl /opt/fhem/fhem.pl 7072 'attr SensorDaten room 242_Sturmwetterwarnung'
perl /opt/fhem/fhem.pl 7072 'attr SensorDaten icon weather_wind_speed@SkyBlue'

perl /opt/fhem/fhem.pl 7072 'save'

# install_windboe_dummy.sh

perl /opt/fhem/fhem.pl 7072 'define Schwellwert_Windstaerke dummy'
perl /opt/fhem/fhem.pl 7072 'attr Schwellwert_Windstaerke room 242_Sturmwetterwarnung'
perl /opt/fhem/fhem.pl 7072 'set Schwellwert_Windstaerke 200'

perl /opt/fhem/fhem.pl 7072 'define Schwellwert_Windboe dummy'
perl /opt/fhem/fhem.pl 7072 'attr Schwellwert_Windboe room 242_Sturmwetterwarnung'
perl /opt/fhem/fhem.pl 7072 'set Schwellwert_Windboe 200'

perl /opt/fhem/fhem.pl 7072 'define SturmwarnungSchalter dummy'
perl /opt/fhem/fhem.pl 7072 'attr SturmwarnungSchalter room 242_Sturmwetterwarnung'
perl /opt/fhem/fhem.pl 7072 'attr SturmwarnungSchalter webCmd on:off'
perl /opt/fhem/fhem.pl 7072 'define MerkerSchalterBoe dummy'
perl /opt/fhem/fhem.pl 7072 'attr MerkerSchalterBoe room 242_Sturmwetterwarnung'
perl /opt/fhem/fhem.pl 7072 'attr MerkerSchalterBoe webCmd on:off'
perl /opt/fhem/fhem.pl 7072 'define MerkerSchalterWindstaerke dummy'
perl /opt/fhem/fhem.pl 7072 'attr MerkerSchalterWindstaerke room 242_Sturmwetterwarnung '
perl /opt/fhem/fhem.pl 7072 'attr MerkerSchalterWindstaerke webCmd on:off'

perl /opt/fhem/fhem.pl 7072 'define UeberschreitenSchwellenwertWindstaerke DOIF ([Schwellwert_Windstaerke:state] < [SensorDaten:Windgeschwindigkeit] and [SturmwarnungSchalter:state] eq "on" and [MerkerSchalterWindstaerke:state] eq "off") (set SensorDatenFhem_bot message Achtung! Windgeschwindigkeit wurde überschritten. Aktuelle Windgeschwindigkeit: [SensorDaten:Windgeschwindigkeit] km/h)(set MerkerSchalterWindstaerke on)'
perl /opt/fhem/fhem.pl 7072 'attr UeberschreitenSchwellenwertWindstaerke room 242_Sturmwetterwarnung'
perl /opt/fhem/fhem.pl 7072 'define UeberschreitenSchwellenwertBoe DOIF ([Schwellwert_Windboe:state] < [SensorDaten:Böe] and [SturmwarnungSchalter:state] eq "on" and [MerkerSchalterBoe:state] eq "off") (set SensorDatenFhem_bot message Achtung! Böengeschwindigkeit wurde überschritten. Aktuelle Böengeschwindigkeit: [SensorDaten:Böe] km/h) (set MerkerSchalterBoe on)'
perl /opt/fhem/fhem.pl 7072 'attr UeberschreitenSchwellenwertBoe room 242_Sturmwetterwarnung'
perl /opt/fhem/fhem.pl 7072 'define UnterschreitenSchwellenwertBoe DOIF ([Schwellwert_Windboe:state] > [(SensorDaten:Böe*1.3)] and [SturmwarnungSchalter:state] eq "on" and [MerkerSchalterBoe:state] eq "on") (set SensorDatenFhem_bot message Die Wetterlage hat sich beruhigt. Aktuelle Böengeschwindigkeit: [SensorDaten:Böe] km/h)(set MerkerSchalterBoe off)'
perl /opt/fhem/fhem.pl 7072 'attr UnterschreitenSchwellenwertBoe room 242_Sturmwetterwarnung'
perl /opt/fhem/fhem.pl 7072 'define UnterschreitenSchwellenwertWindstaerke DOIF ([Schwellwert_Windstaerke:state] > [SensorDaten:Windgeschwindigkeit*1.3] and [SturmwarnungSchalter:state] eq "on" and [MerkerSchalterWindstaerke:state] eq "on") (set SensorDatenFhem_bot message Die Wetterlage hat sich beruhigt. Aktuelle Windgeschwindigkeit: [SensorDaten:Windgeschwindigkeit] km/h)(set MerkerSchalterWindstaerke off)'
perl /opt/fhem/fhem.pl 7072 'attr UnterschreitenSchwellenwertWindstaerke room 242_Sturmwetterwarnung'

perl /opt/fhem/fhem.pl 7072 'save'


# install_einfaches_heizen.sh

perl /opt/fhem/fhem.pl 7072 'setreading balkonkraftwerk energieSchwellwert 300'
perl /opt/fhem/fhem.pl 7072 'define doif_UeberschreitenEnergieSchwellenwert DOIF ([+([doif_UeberschreitenEnergieSchwellenwert:intervall]*60)] and [balkonkraftwerk:power_0] > [balkonkraftwerk:energieSchwellwert] and [infrarotheizung:relay_1] eq “off”) (set infrarotheizung on) DOELSEIF ([+([doif_UeberschreitenEnergieSchwellenwert:intervall]*60)] and [balkonkraftwerk:power_0] < [balkonkraftwerk:energieSchwellwert] and [infrarotheizung:relay_1] eq “on”) (set infrarotheizung off)'
perl /opt/fhem/fhem.pl 7072 'attr doif_UeberschreitenEnergieSchwellenwert room 243_Balkonkraftwerk'
perl /opt/fhem/fhem.pl 7072 'attr doif_UeberschreitenEnergieSchwellenwert disable 1'
perl /opt/fhem/fhem.pl 7072 'setreading doif_UeberschreitenEnergieSchwellenwert intervall 5'
perl /opt/fhem/fhem.pl 7072 'attr doif_UeberschreitenEnergieSchwellenwert disable 0'
perl /opt/fhem/fhem.pl 7072 'attr doif_UeberschreitenEnergieSchwellenwert do always'


perl /opt/fhem/fhem.pl 7072 'define doif_HeizungEinfach DOIF ([infrarotheizung:relay_1] eq "on")(set infrarotheizung off)(attr doif_UeberschreitenEnergieSchwellenwert disable 1)(setreading doif_HeizungEinfach disable 1)'
perl /opt/fhem/fhem.pl 7072 'attr doif_HeizungEinfach room 243_Balkonkraftwerk'
perl /opt/fhem/fhem.pl 7072 'setreading doif_HeizungEinfach disable 1'
perl /opt/fhem/fhem.pl 7072 'setreading doif_HeizungEinfach on_time 120'
perl /opt/fhem/fhem.pl 7072 'attr doif_HeizungEinfach do resetwait'
perl /opt/fhem/fhem.pl 7072 'attr doif_HeizungEinfach wait [doif_HeizungEinfach:on_time]*60'


perl /opt/fhem/fhem.pl 7072 'define doif_disableTimerEinfach DOIF ([doif_HeizungEinfach:disable] eq "1") (attr doif_UeberschreitenEnergieSchwellenwert disable 0) (setreading doif_HeizungEinfach disable 0)'
perl /opt/fhem/fhem.pl 7072 'attr doif_disableTimerEinfach room 243_Balkonkraftwerk'
perl /opt/fhem/fhem.pl 7072 'attr doif_disableTimerEinfach disable 1'
perl /opt/fhem/fhem.pl 7072 'setreading doif_disableTimerEinfach disabled {AttrVal(“doif_UeberschreitenEnergieSchwellenWert”,”disable”,2)}'
perl /opt/fhem/fhem.pl 7072 'setreading doif_disableTimerEinfach off_time 15'
perl /opt/fhem/fhem.pl 7072 'attr doif_disableTimerEinfach do resetwait'
perl /opt/fhem/fhem.pl 7072 'attr doif_disableTimerEinfach wait [doif_disableTimerEinfach:off_time]*60'

perl /opt/fhem/fhem.pl 7072 'attr doif_UeberschreitenEnergieSchwellenwert disable 1'
perl /opt/fhem/fhem.pl 7072 'attr doif_HeizungEinfach disable 1 '

perl /opt/fhem/fhem.pl 7072 'save'

# install_sensor_hobbyraum.sh

perl /opt/fhem/fhem.pl 7072 'define Temperatursensor HTTPMOD https://measurements.mobile-alerts.eu/Home/MeasurementDetails?deviceid=035DD29D94C5&vendorid=244DD836-16DE-465E-B265-B3F1596A26D4&appbundle=de.synertronixx.remotemonitor 420'
perl /opt/fhem/fhem.pl 7072 'attr Temperatursensor reading01Regex requestHeader1'
perl /opt/fhem/fhem.pl 7072 'attr Temperatursensor requestHeader1 User-Agent: Mozilla/5.0 (Windows NT 6.0)'
perl /opt/fhem/fhem.pl 7072 'attr Temperatursensor enableCookies 1'
perl /opt/fhem/fhem.pl 7072 'attr Temperatursensor reading02Name temperature'
perl /opt/fhem/fhem.pl 7072 'attr Temperatursensor reading02Expr join ".", (split /,/, $val)'
perl /opt/fhem/fhem.pl 7072 'attr Temperatursensor reading02Regex ([^>]\d*[,]\d)'
perl /opt/fhem/fhem.pl 7072 'attr Temperatursensor reading03Name timestamp'
perl /opt/fhem/fhem.pl 7072 'attr Temperatursensor reading03Regex ([^>]\d+[.]\d+[.]\d+\s\d+[:]\d+[:]\d+)'
perl /opt/fhem/fhem.pl 7072 'attr Temperatursensor reading04Name humidity'
perl /opt/fhem/fhem.pl 7072 'attr Temperatursensor reading04Regex ([^>]\d*[,]\d)[%]'
perl /opt/fhem/fhem.pl 7072 'attr Temperatursensor reading04Expr join ".", (split /,/, $val)'
perl /opt/fhem/fhem.pl 7072 'attr Temperatursensor event-on-change-reading .*'
perl /opt/fhem/fhem.pl 7072 'attr Temperatursensor icon temp_outside@SkyBlue '
perl /opt/fhem/fhem.pl 7072 'attr Temperatursensor room 243_Balkonkraftwerk '
perl /opt/fhem/fhem.pl 7072 'save'

# install_optHeizen_dummy.sh

perl /opt/fhem/fhem.pl 7072 'define OptimiertesHeizenSchalter dummy'
perl /opt/fhem/fhem.pl 7072 'attr OptimiertesHeizenSchalter room 243_Balkonkraftwerk'
perl /opt/fhem/fhem.pl 7072 'attr OptimiertesHeizenSchalter webCmd on:off'

perl /opt/fhem/fhem.pl 7072 'define Schwellwert_Temperatur_Ein dummy'
perl /opt/fhem/fhem.pl 7072 'attr Schwellwert_Temperatur_Ein room 243_Balkonkraftwerk '
perl /opt/fhem/fhem.pl 7072 'set Schwellwert_Temperatur_Ein 19'

perl /opt/fhem/fhem.pl 7072 'define Schwellwert_Temperatur_Aus dummy'
perl /opt/fhem/fhem.pl 7072 'attr Schwellwert_Temperatur_Aus room 243_Balkonkraftwerk '
perl /opt/fhem/fhem.pl 7072 'set Schwellwert_Temperatur_Aus 21'

perl /opt/fhem/fhem.pl 7072 'define Schwellwert_Luftfeuchtigkeit_Ein dummy'
perl /opt/fhem/fhem.pl 7072 'attr Schwellwert_Luftfeuchtigkeit_Ein room 243_Balkonkraftwerk'
perl /opt/fhem/fhem.pl 7072 'set Schwellwert_Luftfeuchtigkeit_Ein 75'

perl /opt/fhem/fhem.pl 7072 'define Schwellwert_Luftfeuchtigkeit_Aus dummy'
perl /opt/fhem/fhem.pl 7072 'attr Schwellwert_Luftfeuchtigkeit_Aus room 243_Balkonkraftwerk'
perl /opt/fhem/fhem.pl 7072 'set Schwellwert_Luftfeuchtigkeit_Aus 70'

perl /opt/fhem/fhem.pl 7072 'save'

# install_optHeizen_infrarot.sh

perl /opt/fhem/fhem.pl 7072 'define EinschaltenOptimiertesHeizen DOIF (([Schwellwert_Temperatur_Ein:state] > [Temperatursensor:temperature] or [Schwellwert_Luftfeuchtigkeit_Ein:state] < [Temperatursensor:humidity]) and [OptimiertesHeizenSchalter:state] eq "on" and [+([doif_UeberschreitenEnergieSchwellenwert:intervall]*60)] and [balkonkraftwerk:power_0] > [balkonkraftwerk:energieSchwellwert] and [infrarotheizung:relay_1] eq "off")(set infrarotheizung on)'
perl /opt/fhem/fhem.pl 7072 'attr EinschaltenOptimiertesHeizen room 243_Balkonkraftwerk'
perl /opt/fhem/fhem.pl 7072 'attr EinschaltenOptimiertesHeizen do always'
perl /opt/fhem/fhem.pl 7072 'setreading EinschaltenOptimiertesHeizen EnergyTimeRange 60'
perl /opt/fhem/fhem.pl 7072 'define AusschaltenOptimiertesHeizen DOIF ([Schwellwert_Temperatur_Aus:state] < [Temperatursensor:temperature] and [Schwellwert_Luftfeuchtigkeit_Aus:state] > [Temperatursensor:humidity] and [OptimiertesHeizenSchalter:state] eq "on" and [+([doif_UeberschreitenEnergieSchwellenwert:intervall]*60)]) (set infrarotheizung off)'
perl /opt/fhem/fhem.pl 7072 'attr AusschaltenOptimiertesHeizen room 243_Balkonkraftwerk'
perl /opt/fhem/fhem.pl 7072 'attr AusschaltenOptimiertesHeizen do always'
perl /opt/fhem/fhem.pl 7072 'setreading AusschaltenOptimiertesHeizen EnergyTimeRange 60'
perl /opt/fhem/fhem.pl 7072 'save'


perl /opt/fhem/fhem.pl 7072 'define doif_HeizungOptimierend DOIF ([infrarotheizung:relay_1] eq "on")(set infrarotheizung off)(attr EinschaltenOptimiertesHeizen disable 1)(setreading doif_HeizungOptimierend disable 1)'
perl /opt/fhem/fhem.pl 7072 'attr doif_HeizungOptimierend room 243_Balkonkraftwerk'
perl /opt/fhem/fhem.pl 7072 'setreading doif_HeizungOptimierend disable 1'
perl /opt/fhem/fhem.pl 7072 'attr doif_HeizungOptimierend do resetwait'
perl /opt/fhem/fhem.pl 7072 'attr doif_HeizungOptimierend wait [doif_HeizungEinfach:on_time]*60'


perl /opt/fhem/fhem.pl 7072 'define doif_disableTimerOptimierend DOIF ([doif_HeizungOptimierend:disable] eq "1")(attr EinschaltenOptimiertesHeizen disable 0) (setreading doif_HeizungOptimierend disable 0)'
perl /opt/fhem/fhem.pl 7072 'attr doif_disableTimerOptimierend room 243_Balkonkraftwerk'
perl /opt/fhem/fhem.pl 7072 'attr doif_disableTimerOptimierend disable 1'
perl /opt/fhem/fhem.pl 7072 'setreading doif_disableTimerOptimierend disabled {AttrVal(“doif_UeberschreitenEnergieSchwellenWert”,”disable”,2)}'
perl /opt/fhem/fhem.pl 7072 'attr doif_disableTimerOptimierend do resetwait'
perl /opt/fhem/fhem.pl 7072 'attr doif_disableTimerOptimierend wait [doif_disableTimerEinfach:off_time]*60'

perl /opt/fhem/fhem.pl 7072 'attr EinschaltenOptimiertesHeizen disable 1 '
perl /opt/fhem/fhem.pl 7072 'attr AusschaltenOptimiertesHeizen disable 1'
perl /opt/fhem/fhem.pl 7072 'attr doif_HeizungOptimierend disable 1'

perl /opt/fhem/fhem.pl 7072 'save'


# install_modullogik_heizen.sh

perl /opt/fhem/fhem.pl 7072 'define heizenModus dummy'
perl /opt/fhem/fhem.pl 7072 'attr heizenModus room 243_Balkonkraftwerk'
perl /opt/fhem/fhem.pl 7072 'attr heizenModus setList switch:einfach,optimierend,aus'

perl /opt/fhem/fhem.pl 7072 'define doif_heizenModus DOIF ([heizenModus:"einfach"]) (attr doif_UeberschreitenEnergieSchwellenwert disable 0) (attr doif_HeizungEinfach disable 0) (attr doif_disableTimerEinfach disable 0) (attr doif_HeizungOptimierend disable 1) (attr doif_disableTimerOptimierend disable 1) (attr EinschaltenOptimiertesHeizen disable 1) (attr AusschaltenOptimiertesHeizen disable 1) (set OptimiertesHeizenSchalter off) DOELSEIF ([heizenModus:"optimierend"]) (attr EinschaltenOptimiertesHeizen disable 0) (attr AusschaltenOptimiertesHeizen disable 0) (attr doif_HeizungEinfach disable 1) (attr doif_disableTimerEinfach disable 1) (attr doif_HeizungOptimierend disable 0) (attr doif_disableTimerOptimierend disable 0) (set OptimiertesHeizenSchalter on) (attr doif_UeberschreitenEnergieSchwellenwert disable 1) DOELSEIF ([heizenModus:"aus"]) (attr doif_UeberschreitenEnergieSchwellenwert disable 1) (attr EinschaltenOptimiertesHeizen disable 1) (attr AusschaltenOptimiertesHeizen disable 1) (attr doif_HeizungEinfach disable 1)(attr doif_disableTimerEinfach disable 1) (attr doif_HeizungOptimierend disable 1) (attr doif_disableTimerOptimierend disable 1) (set infrarotheizung off) (set OptimiertesHeizenSchalter off)'

perl /opt/fhem/fhem.pl 7072 'attr doif_heizenModus room 243_Balkonkraftwerk'
perl /opt/fhem/fhem.pl 7072 'save'

# install_stromwerttabelle.sh

perl /opt/fhem/fhem.pl 7072 'define stromwerttabelle dummy'
perl /opt/fhem/fhem.pl 7072 'attr stromwerttabelle room 243_Wasserboiler'

perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle t1 0'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle t1_on 00:00'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle t1_off 00:00'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle t2 0'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle t2_on 00:00'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle t2_off 00:00'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle t3 0'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle t3_on 00:00'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle t3_off 00:00'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle t4 0'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle t4_on 00:00'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle t4_off 00:00'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle t5 0'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle t5_on 00:00'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle t5_off 00:00'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle t6 0'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle t6_on 00:00'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle t6_off 00:00'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle we 0'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle we_on 00:00'
perl /opt/fhem/fhem.pl 7072 'setreading stromwerttabelle we_off 00:00'


perl /opt/fhem/fhem.pl 7072 'define a_boiler_stromwert at +*00:00:10 {modusStromwerttabelle()}'
perl /opt/fhem/fhem.pl 7072 'attr a_boiler_stromwert room 243_Wasserboiler'

perl /opt/fhem/fhem.pl 7072 'save'

# install_wasserboiler
perl /opt/fhem/fhem.pl 7072 'Define a_boiler_zeit_on at *00:00:10 set wasserBoiler on'
perl /opt/fhem/fhem.pl 7072 'setreading a_boiler_zeit_on datum 30-12-3022'
perl /opt/fhem/fhem.pl 7072 'Modify a_boiler_zeit_on  *{parseDate("a_boiler_zeit_on")} set wasserBoiler on' 
perl /opt/fhem/fhem.pl 7072 'attr a_boiler_zeit_on room 243_Wasserboiler'

perl /opt/fhem/fhem.pl 7072 'Define a_boiler_zeit_off at *00:00:10 set wasserBoiler off'
perl /opt/fhem/fhem.pl 7072 'setreading a_boiler_zeit_off datum 31-12-3022'
perl /opt/fhem/fhem.pl 7072 'Modify a_boiler_zeit_off *{parseDate("a_boiler_zeit_off")} set wasserBoiler off' 
perl /opt/fhem/fhem.pl 7072 'attr a_boiler_zeit_off room 243_Wasserboiler'

perl /opt/fhem/fhem.pl 7072 'Define doif_boiler_schwellwert DOIF ([+([doif_boiler_schwellwert:intervall]*60)] and([balkonkraftwerk:power_0] > [wasserBoiler:schwellwert]))(set wasserBoiler on)DOELSEIF ([+([doif_boiler_schwellwert:intervall]*60)] and([balkonkraftwerk:power_0] < [wasserBoiler:schwellwert]))(set wasserBoiler off)'
perl /opt/fhem/fhem.pl 7072 'Setreading wasserBoiler schwellwet 500'
perl /opt/fhem/fhem.pl 7072 'attr doif_boiler_schwellwert room 243_Wasserboiler'

perl /opt/fhem/fhem.pl 7072 'define doif_wasserboiler_general DOIF ([wasserBoilerModus:"manuell"])(attr a_boiler_zeit_on disable 1)(attr a_boiler_zeit_off disable 1)(attr doif_boiler_schwellwert disable 1)(attr a_boiler_stromwert disable 1)DOELSEIF ([wasserBoilerModus:"festeZeit"])(attr a_boiler_zeit_on disable 0)(attr a_boiler_zeit_off disable 0)(attr doif_boiler_schwellwert disable 1)(attr a_boiler_stromwert disable 1)DOELSEIF ([wasserBoilerModus:"stromwert"])(attr a_boiler_zeit_on disable 1)(attr a_boiler_zeit_off disable 1)(attr doif_boiler_schwellwert disable 1)(attr a_boiler_stromwert disable 0)DOELSEIF ([wasserBoilerModus:"schwellwert"])(attr a_boiler_zeit_on disable 1)(attr a_boiler_zeit_off disable 1)(attr doif_boiler_schwellwert disable 0)(attr a_boiler_stromwert disable 1)'
perl /opt/fhem/fhem.pl 7072 'attr doif_wasserboiler_general room 243_Wasserboiler'

perl /opt/fhem/fhem.pl 7072 'define wasserBoilerModus dummy'
perl /opt/fhem/fhem.pl 7072 'attr wasserBoilerModus setList switch: manuell festeZeit stromwert schwell'
perl /opt/fhem/fhem.pl 7072 'attr wasserBoilerModus room 243_Wasserboiler'

perl /opt/fhem/fhem.pl 7072 'save'


# install_kombiBoiler_infrarot.sh

perl /opt/fhem/fhem.pl 7072 'define doif_kombinationHeizungBoiler01 DOIF ([balkonkraftwerk:power_0] < [infrarotheizung:power_1] and [wasserBoilerModus] eq "stromwert") (set infrarotheizung off) ( set wasserBoiler off)   DOELSEIF ([balkonkraftwerk:power_0] < [infrarotheizung:power_1]) (set infrarotheizung off) '
perl /opt/fhem/fhem.pl 7072 'attr doif_kombinationHeizungBoiler01 room 243_Balkonkraftwerk '
perl /opt/fhem/fhem.pl 7072 'define doif_kombinationHeizungBoiler02 DOIF ([balkonkraftwerk:power_0] > [infrarotheizung:power_1] and  [balkonkraftwerk:power_0] < ([infrarotheizung:power_1] + [wasserBoiler:schwellwert]) and [wasserBoilerModus] eq "stromwert") (set wasserBoiler off)'
perl /opt/fhem/fhem.pl 7072 'attr doif_kombinationHeizungBoiler02 room 243_Balkonkraftwerk '
perl /opt/fhem/fhem.pl 7072 'save'

# install_abfall.sh


perl /opt/fhem/fhem.pl 7072 "define abfallKalender Calendar ical url https://www.avl-ludwigsburg.de/fileadmin/Files/Abfallkalender/ICS/Privat/Privat_2022_Bietigheim-Stadt-und-Metterzimmern.ics"

perl /opt/fhem/fhem.pl 7072 'define myABFALLKalender ABFALL abfallKalender'
perl /opt/fhem/fhem.pl 7072 'attr abfallKalender room 97_Abfall'
perl /opt/fhem/fhem.pl 7072 'attr myABFALLKalender room 97_Abfall'

perl /opt/fhem/fhem.pl 7072 'save'